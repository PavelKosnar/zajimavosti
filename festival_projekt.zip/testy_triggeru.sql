-- Demonstrace pravidel hlídaných triggerem check_assignment() a CHECK omezeními.
-- Spouštějte až po festival.sql + festival_seed.sql. Skript nemění data a lze ho opakovat:
-- neplatné zápisy jsou odmítnuty (a zachyceny), platný zápis je na konci vrácen zpět (ROLLBACK).

DO $$ BEGIN
    INSERT INTO festival.shift_assignments (shift_id, volunteer_id) VALUES (5, 7);
    RAISE NOTICE 'CHYBA: zápis bez kvalifikace měl být odmítnut';
EXCEPTION WHEN check_violation THEN
    RAISE NOTICE '1) Bez kvalifikace (Veselá -> Zdravotní dohled): ODMÍTNUTO – %', SQLERRM;
END $$;

DO $$ BEGIN
    INSERT INTO festival.shift_assignments (shift_id, volunteer_id) VALUES (7, 1);
    RAISE NOTICE 'CHYBA: kolize směn měla být odmítnuta';
EXCEPTION WHEN check_violation THEN
    RAISE NOTICE '2) Kolize směn (Malá už 20.6. 16–22 na baru): ODMÍTNUTO – %', SQLERRM;
END $$;

DO $$ BEGIN
    INSERT INTO festival.shift_assignments (shift_id, volunteer_id) VALUES (3, 7);
    RAISE NOTICE 'CHYBA: přeplnění směny mělo být odmítnuto';
EXCEPTION WHEN check_violation THEN
    RAISE NOTICE '3) Přeplněná směna (3. člověk na Vstupy 19.6.): ODMÍTNUTO – %', SQLERRM;
END $$;

DO $$ BEGIN
    UPDATE festival.shift_assignments SET checked_in_at = now() WHERE assignment_id = 4;
    RAISE NOTICE 'CHYBA: docházka u nepotvrzeného přiřazení měla být odmítnuta';
EXCEPTION WHEN check_violation THEN
    RAISE NOTICE '4) Docházka u nepotvrzeného přiřazení (CHECK): ODMÍTNUTO – %', SQLERRM;
END $$;

BEGIN;
    INSERT INTO festival.shift_assignments (shift_id, volunteer_id) VALUES (7, 7);
    SELECT 'Platný zápis (Veselá -> Vstupy 20.6.) PROŠEL; počet aktivních na směně 7:' AS info,
           count(*) AS pocet
    FROM festival.shift_assignments
    WHERE shift_id = 7 AND status IN ('signed_up', 'confirmed');
ROLLBACK;
