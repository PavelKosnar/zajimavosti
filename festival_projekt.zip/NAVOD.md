# Návod k předvedení a spuštění

Zadání: *„Budete odevzdávat část datové analýzy projektu (ERD, DDL a DML skripty). Prosím, nachystejte si skripty předem tak, aby je bylo možné přede mnou opakovaně spustit.“*

## Co mít připravené před cvičením

| Požadavek | Soubor |
|---|---|
| ERD (konceptuální model) | `erd.pdf` / `erd.png` |
| Relační model + popis tabulek | `festival_projekt.pdf` |
| DDL skript | `festival.sql` |
| DML skript | `festival_seed.sql` |
| DDL + DML v jednom kroku | `festival_vse.sql` |
| Diagram v dbdiagram.io | `festival.dbml` (vložit do levého editoru) |

Před cvičením si **jednou vyzkoušejte, že vše běží na vašem počítači** (PostgreSQL, viz níže). Zjistěte u cvičícího, jestli používá PostgreSQL (vzorový projekt je v něm).

## Spuštění

**Příkazová řádka (psql):**
```bash
psql -U <uzivatel> -d <databaze> -f festival.sql -f festival_seed.sql
# nebo vše naráz:
psql -U <uzivatel> -d <databaze> -f festival_vse.sql
```

**pgAdmin / DBeaver / jiný klient:** otevřete `festival_vse.sql` a spusťte celý skript (pgAdmin: F5, DBeaver: Alt+X, tedy „Execute script“, ne jen jeden příkaz).

Skripty jsou **opakovatelné**:
- `festival.sql` na začátku smaže schéma `festival` (`DROP SCHEMA ... CASCADE`) a vytvoří ho znovu,
- `festival_seed.sql` na začátku vyprázdní tabulky (`TRUNCATE ... RESTART IDENTITY`), takže jde spustit i samostatně vícekrát.

Vyzkoušeno: DDL + DML opakovaně, DML samotné opakovaně, `festival_vse.sql` opakovaně, vše bez chyby.

## Doporučený postup při předvádění (cca 5 minut)

1. **ERD** (`erd.pdf`): 5 entit, 5 vazeb; vysvětlete M:N vazby (dobrovolník–pozice = kvalifikace, dobrovolník–směna = přiřazení).
2. **Relační model** (`festival_projekt.pdf` nebo dbdiagram.io s `festival.dbml`): 7 tabulek, u každé řekněte, co je jeden záznam.
3. **Spusťte `festival_vse.sql`** (DDL + DML). Na požádání spusťte znovu a ukažte, že běží opakovaně.
4. **Ukažte data:** `SELECT * FROM festival.shift_assignments;`
5. **Vzorové dotazy** (`vzorove_selecty.sql`): obsazenost směn, odpracované hodiny a odměny, koho oslovit.
6. **`testy_triggeru.sql`:** ukáže odmítnutí zápisu bez kvalifikace, kolize směn a přeplněné směny.

Očekávané výsledky: směna 7 má chybějící 1 člověka; hodiny Malá 12,17 / Beneš 12,00 / Horáková 10,00 / Němcová 7,92 / Kovář 6,00; na směnu 7 vychází jediný vhodný kandidát Karolína Veselá.

## Na co se vás může cvičící zeptat

- **Proč se odpracované hodiny neukládají?** Byly by redundantní a mohly by se rozjet s docházkou; počítají se dotazem z `checked_in_at` a `checked_out_at`.
- **Proč je `qualifications` samostatná tabulka?** Vazba M:N dobrovolník–pozice; nese i atribut `obtained_on`.
- **Proč `is_active` a `status` místo mazání?** Zachování historie ročníků.
- **K čemu je trigger a proč ne CHECK?** Pravidla (kvalifikace, kolize, kapacita) se týkají více řádků a tabulek, což CHECK neumí.
- **Co trigger nehlídá?** Pozdější změnu času směny nebo odebrání kvalifikace (uvedeno jako možné rozšíření).
- **Proč `timestamptz`, `numeric`?** Přesná práce s časem v časových pásmech a s desetinnými hodnotami bez zaokrouhlovacích chyb.
- **Proč v `festival.sql` je `DROP SCHEMA`?** Aby šlo skript spouštět opakovaně; pozor, maže data ve schématu `festival`.
