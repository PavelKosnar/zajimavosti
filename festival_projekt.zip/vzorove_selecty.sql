-- Vzorové dotazy. Pro jiný ročník změňte event_id v CTE selected_event.

-- 1) Obsazenost směn: kolik lidí je potřeba, kolik je přihlášeno / potvrzeno a kolik chybí.
WITH selected_event AS (SELECT 2::integer AS event_id)
SELECT
    s.shift_id,
    p.name AS position_name,
    to_char(s.starts_at AT TIME ZONE 'Europe/Prague', 'DD.MM. HH24:MI') AS starts,
    to_char(s.ends_at   AT TIME ZONE 'Europe/Prague', 'HH24:MI')       AS ends,
    s.required_count,
    count(*) FILTER (WHERE a.status = 'confirmed') AS confirmed,
    count(*) FILTER (WHERE a.status = 'signed_up') AS signed_up,
    greatest(s.required_count - count(*) FILTER (WHERE a.status IN ('confirmed', 'signed_up')), 0) AS missing
FROM selected_event AS se
JOIN festival.shifts AS s ON s.event_id = se.event_id
JOIN festival.positions AS p ON p.position_id = s.position_id
LEFT JOIN festival.shift_assignments AS a ON a.shift_id = s.shift_id
GROUP BY s.shift_id, p.name, s.starts_at, s.ends_at, s.required_count
ORDER BY s.starts_at, s.shift_id;

-- 2) Odpracované hodiny a získané odměny.
--    Hodiny se počítají jen z potvrzených směn s vyplněným příchodem i odchodem;
--    nic se neukládá, vždy se počítá z docházky.
WITH selected_event AS (SELECT 2::integer AS event_id),
worked AS (
    SELECT a.volunteer_id,
           round(sum(extract(epoch FROM a.checked_out_at - a.checked_in_at)) / 3600.0, 2) AS hours
    FROM festival.shift_assignments AS a
    JOIN festival.shifts AS s ON s.shift_id = a.shift_id
    JOIN selected_event AS se ON se.event_id = s.event_id
    WHERE a.status = 'confirmed' AND a.checked_out_at IS NOT NULL
    GROUP BY a.volunteer_id
)
SELECT
    v.last_name, v.first_name,
    w.hours AS worked_hours,
    coalesce(string_agg(r.name, ', ' ORDER BY r.required_hours), '–') AS earned_rewards
FROM worked AS w
JOIN festival.volunteers AS v ON v.volunteer_id = w.volunteer_id
CROSS JOIN selected_event AS se
LEFT JOIN festival.rewards AS r ON r.event_id = se.event_id AND r.required_hours <= w.hours
GROUP BY v.volunteer_id, v.last_name, v.first_name, w.hours
ORDER BY w.hours DESC, v.last_name;

-- 3) Koho oslovit: aktivní dobrovolníci vhodní na nedoobsazené směny
--    (mají kvalifikaci, pokud je třeba, nejsou na směně a nemají kolizi v čase).
WITH selected_event AS (SELECT 2::integer AS event_id),
open_shifts AS (
    SELECT s.shift_id, s.position_id, s.starts_at, s.ends_at, p.name AS position_name,
           p.requires_qualification,
           s.required_count - count(*) FILTER (WHERE a.status IN ('confirmed', 'signed_up')) AS missing
    FROM selected_event AS se
    JOIN festival.shifts AS s ON s.event_id = se.event_id
    JOIN festival.positions AS p ON p.position_id = s.position_id
    LEFT JOIN festival.shift_assignments AS a ON a.shift_id = s.shift_id
    GROUP BY s.shift_id, s.position_id, s.starts_at, s.ends_at, p.name, p.requires_qualification, s.required_count
    HAVING s.required_count - count(*) FILTER (WHERE a.status IN ('confirmed', 'signed_up')) > 0
)
SELECT
    o.shift_id, o.position_name, o.missing,
    v.volunteer_id, v.first_name, v.last_name, v.email
FROM open_shifts AS o
JOIN festival.volunteers AS v ON v.is_active
WHERE (NOT o.requires_qualification
       OR EXISTS (SELECT 1 FROM festival.qualifications AS q
                  WHERE q.volunteer_id = v.volunteer_id AND q.position_id = o.position_id))
  AND NOT EXISTS (
        SELECT 1
        FROM festival.shift_assignments AS a
        JOIN festival.shifts AS s ON s.shift_id = a.shift_id
        WHERE a.volunteer_id = v.volunteer_id
          AND (a.shift_id = o.shift_id
               OR (a.status IN ('confirmed', 'signed_up')
                   AND s.starts_at < o.ends_at AND s.ends_at > o.starts_at)))
ORDER BY o.shift_id, v.last_name;
