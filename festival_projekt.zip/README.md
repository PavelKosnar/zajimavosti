# Evidence dobrovolníků a směn na festivalu

## Příběhové zadání

Dobrovolnicky pomáhám s organizací hudebního festivalu v Ostravě. Každý rok potřebujeme desítky lidí na barech, u vstupů, na infostánku, u pódia i ve zdravotním dohledu. Směny dosud rozepisujeme v tabulce a na e-mailech: nikdo přesně neví, které směny jsou ještě neobsazené, lidé se omylem zapíšou na dvě směny ve stejnou dobu a po festivalu se ručně dohledává, kolik hodin kdo odpracoval a na jakou odměnu má nárok (tričko, vstupenka pro doprovod, večeře).

Některé pozice vyžadují kvalifikaci (zdravotnický kurz, školení BOZP pro techniky pódia); na ně se nesmí přihlásit kdokoli. Dobrovolníci se mohou hlásit i odhlásit, někdo se na směnu nedostaví. Neaktivní dobrovolníky ani odhlášená přiřazení nechci mazat, protože se z nich skládá historie dalších ročníků.

Potřebuji proto evidovat dobrovolníky, ročníky festivalu, pozice, kvalifikace, směny, přiřazení dobrovolníků na směny včetně skutečné docházky a odměny za odpracované hodiny. Odpracované hodiny se nemají ukládat ručně, ale vždy se mají počítat z docházky.

## 1. Popis systému

Systém slouží koordinátorovi dobrovolníků. Eviduje, kdo je dobrovolník, jaké má kvalifikace, jaké směny se na akci vypisují a kdo je na ně přiřazen. Umožňuje zjistit obsazenost směn, odpracované hodiny, nárok na odměny a to, koho oslovit na neobsazené směny.

## 2. Model (7 tabulek)

| Tabulka | Jeden záznam představuje |
|---|---|
| `volunteers` | jednoho dobrovolníka |
| `events` | jeden ročník festivalu |
| `positions` | jeden druh pozice (zda vyžaduje kvalifikaci) |
| `qualifications` | kvalifikaci dobrovolníka pro pozici (M:N) |
| `shifts` | jednu směnu: čas, pozice a počet potřebných lidí |
| `shift_assignments` | přiřazení dobrovolníka na směnu, stav a docházku (M:N) |
| `rewards` | odměnu na akci s hranicí odpracovaných hodin |

Vazby: `volunteers`–`qualifications`–`positions` (M:N), `volunteers`–`shift_assignments`–`shifts` (M:N), `events`→`shifts`, `positions`→`shifts`, `events`→`rewards` (1:N).

## 3. Pravidla a zvolená zjednodušení

- Stav přiřazení: `signed_up` (přihlášen), `confirmed` (potvrzen koordinátorem), `cancelled` (odhlášen), `no_show` (nedostavil se). Záznamy se nemažou.
- Docházku (`checked_in_at`, `checked_out_at`) lze vyplnit jen u potvrzeného přiřazení; odchod musí být po příchodu.
- **Trigger `check_assignment`** u aktivního přiřazení (`signed_up`, `confirmed`) hlídá: (1) kvalifikaci pro pozici, která ji vyžaduje, (2) kolizi s jinou aktivní směnou téhož dobrovolníka, (3) kapacitu směny (`required_count`). Řádek směny se při kontrole zamyká, aby souběžné zápisy kapacitu nepřekročily.
- Trigger kontroluje jen zápisy do `shift_assignments`. Pozdější změna času směny nebo odebrání kvalifikace se nepřekontroluje (možné rozšíření).
- Odpracované hodiny a nárok na odměny se **neukládají**, počítají se dotazem z potvrzených směn s příchodem i odchodem. Odměna se získá při dosažení hranice `required_hours`.
- Pro první verzi: bez přihlašování uživatelů, bez plateb a bez notifikací.

## 4. Vzorové dotazy (`vzorove_selecty.sql`)

1. **Obsazenost směn** – potřeba, potvrzeno, přihlášeno, chybí.
2. **Odpracované hodiny a získané odměny** dobrovolníků ročníku.
3. **Koho oslovit** – aktivní dobrovolníci vhodní na nedoobsazené směny (kvalifikace, bez kolize).

## 5. Soubory a spuštění v PostgreSQL

| Soubor | Obsah |
|---|---|
| `erd.pdf`, `erd.png` | ERD (konceptuální model) |
| `festival_projekt.pdf` | ERD, relační model, popis tabulek, výsledky dotazů |
| `festival.sql` | DDL (schéma, tabulky, omezení, indexy, trigger) |
| `festival_seed.sql` | DML (ukázková data) |
| `festival_vse.sql` | DDL + DML v jednom souboru |
| `vzorove_selecty.sql` | vzorové dotazy |
| `testy_triggeru.sql` | ukázka odmítnutých zápisů, nemění data |
| `festival.dbml` | model pro dbdiagram.io |
| `NAVOD.md` | postup předvedení a možné otázky |

Spuštění: `festival.sql`, potom `festival_seed.sql` (nebo jen `festival_vse.sql`), potom `vzorove_selecty.sql`. Skripty jsou opakovatelné: `festival.sql` na začátku smaže schéma `festival` včetně dat, `festival_seed.sql` vyprázdní tabulky a vynuluje identity. Podrobnosti v `NAVOD.md`.
