-- Ukázková data (DML): festival 2025 (stručně) a festival 2026 (podrobně).
-- Skript lze spouštět opakovaně: nejdřív vyprázdní tabulky a vynuluje identity.
TRUNCATE festival.shift_assignments, festival.rewards, festival.shifts,
         festival.qualifications, festival.positions, festival.events,
         festival.volunteers
    RESTART IDENTITY CASCADE;

INSERT INTO festival.volunteers (volunteer_id, first_name, last_name, email, phone, registered_at, is_active) VALUES
    (1, 'Tereza',   'Malá',       'tereza.mala@example.cz',   '+420601000001', '2025-03-01 10:00:00+01', true),
    (2, 'Jakub',    'Kovář',      'jakub.kovar@example.cz',   '+420601000002', '2025-03-02 11:30:00+01', true),
    (3, 'Lucie',    'Horáková',   'lucie.horakova@example.cz','+420601000003', '2025-03-05 09:15:00+01', true),
    (4, 'Martin',   'Beneš',      'martin.benes@example.cz',  '+420601000004', '2025-03-07 16:40:00+01', true),
    (5, 'Petra',    'Němcová',    'petra.nemcova@example.cz', NULL,            '2026-02-10 12:00:00+01', true),
    (6, 'Ondřej',   'Procházka',  'ondrej.prochazka@example.cz','+420601000006','2025-03-01 10:05:00+01', false),
    (7, 'Karolína', 'Veselá',     'karolina.vesela@example.cz','+420601000007','2026-04-20 18:20:00+02', true);

INSERT INTO festival.events (event_id, name, venue, starts_on, ends_on) VALUES
    (1, 'Ostravský hudební festival 2025', 'Dolní Vítkovice', '2025-06-20', '2025-06-22'),
    (2, 'Ostravský hudební festival 2026', 'Dolní Vítkovice', '2026-06-19', '2026-06-21');

INSERT INTO festival.positions (position_id, name, description, requires_qualification) VALUES
    (1, 'Bar',                   'Čepování a prodej nápojů.',                    false),
    (2, 'Vstupy',                'Kontrola vstupenek a náramků u vstupu.',       false),
    (3, 'Info stánek',           'Informace pro návštěvníky, ztráty a nálezy.',  false),
    (4, 'Zdravotní dohled',      'První pomoc, nutný zdravotnický kurz.',        true),
    (5, 'Technik pódia',         'Pomoc s aparaturou, nutné školení BOZP.',      true);

INSERT INTO festival.qualifications (qualification_id, volunteer_id, position_id, obtained_on) VALUES
    (1, 4, 4, '2023-03-01'),
    (2, 2, 5, '2024-05-10'),
    (3, 2, 1, '2025-06-01');

INSERT INTO festival.shifts (shift_id, event_id, position_id, starts_at, ends_at, required_count) VALUES
    (1, 2, 1, '2026-06-19 16:00:00+02', '2026-06-19 22:00:00+02', 2),
    (2, 2, 1, '2026-06-20 16:00:00+02', '2026-06-20 22:00:00+02', 2),
    (3, 2, 2, '2026-06-19 15:00:00+02', '2026-06-19 19:00:00+02', 2),
    (4, 2, 3, '2026-06-20 10:00:00+02', '2026-06-20 14:00:00+02', 1),
    (5, 2, 4, '2026-06-20 14:00:00+02', '2026-06-20 22:00:00+02', 1),
    (6, 2, 5, '2026-06-19 14:00:00+02', '2026-06-19 20:00:00+02', 1),
    (7, 2, 2, '2026-06-20 15:00:00+02', '2026-06-20 19:00:00+02', 2),
    (8, 1, 1, '2025-06-20 16:00:00+02', '2025-06-20 22:00:00+02', 2),
    (9, 1, 2, '2025-06-21 15:00:00+02', '2025-06-21 19:00:00+02', 1);

INSERT INTO festival.shift_assignments
    (assignment_id, shift_id, volunteer_id, status, checked_in_at, checked_out_at) VALUES
    -- festival 2026
    ( 1, 1, 1, 'confirmed', '2026-06-19 15:55:00+02', '2026-06-19 22:05:00+02'),
    ( 2, 1, 3, 'confirmed', '2026-06-19 16:00:00+02', '2026-06-19 22:00:00+02'),
    ( 3, 2, 1, 'confirmed', '2026-06-20 16:00:00+02', '2026-06-20 22:00:00+02'),
    ( 4, 2, 2, 'signed_up', NULL, NULL),
    ( 5, 2, 5, 'cancelled', NULL, NULL),
    ( 6, 3, 5, 'confirmed', '2026-06-19 15:05:00+02', '2026-06-19 19:00:00+02'),
    ( 7, 3, 4, 'confirmed', '2026-06-19 15:00:00+02', '2026-06-19 19:00:00+02'),
    ( 8, 4, 3, 'confirmed', '2026-06-20 10:00:00+02', '2026-06-20 14:00:00+02'),
    ( 9, 5, 4, 'confirmed', '2026-06-20 14:00:00+02', '2026-06-20 22:00:00+02'),
    (10, 6, 2, 'confirmed', '2026-06-19 14:00:00+02', '2026-06-19 20:00:00+02'),
    (11, 7, 5, 'confirmed', '2026-06-20 15:00:00+02', '2026-06-20 19:00:00+02'),
    (12, 7, 3, 'no_show',   NULL, NULL),
    -- festival 2025
    (13, 8, 1, 'confirmed', '2025-06-20 16:00:00+02', '2025-06-20 22:00:00+02'),
    (14, 8, 6, 'confirmed', '2025-06-20 16:00:00+02', '2025-06-20 22:00:00+02'),
    (15, 9, 6, 'confirmed', '2025-06-21 15:00:00+02', '2025-06-21 19:00:00+02');

INSERT INTO festival.rewards (reward_id, event_id, name, required_hours) VALUES
    (1, 2, 'Festivalové tričko',  6.00),
    (2, 2, 'Vstupenka pro doprovod', 10.00),
    (3, 2, 'Poděkovací večeře',  12.00),
    (4, 1, 'Festivalové tričko',  6.00);

-- Posun identity sekvencí za explicitně vložená ID.
SELECT setval(pg_get_serial_sequence('festival.volunteers', 'volunteer_id'), (SELECT max(volunteer_id) FROM festival.volunteers));
SELECT setval(pg_get_serial_sequence('festival.events', 'event_id'), (SELECT max(event_id) FROM festival.events));
SELECT setval(pg_get_serial_sequence('festival.positions', 'position_id'), (SELECT max(position_id) FROM festival.positions));
SELECT setval(pg_get_serial_sequence('festival.qualifications', 'qualification_id'), (SELECT max(qualification_id) FROM festival.qualifications));
SELECT setval(pg_get_serial_sequence('festival.shifts', 'shift_id'), (SELECT max(shift_id) FROM festival.shifts));
SELECT setval(pg_get_serial_sequence('festival.shift_assignments', 'assignment_id'), (SELECT max(assignment_id) FROM festival.shift_assignments));
SELECT setval(pg_get_serial_sequence('festival.rewards', 'reward_id'), (SELECT max(reward_id) FROM festival.rewards));
